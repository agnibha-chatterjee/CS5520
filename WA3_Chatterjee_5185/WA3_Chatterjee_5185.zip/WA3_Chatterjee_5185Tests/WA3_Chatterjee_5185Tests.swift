//
//  WA3_Chatterjee_5185Tests.swift
//  WA3_Chatterjee_5185Tests
//
//  Created by agni on 9/25/24.
//

import Testing
@testable import WA3_Chatterjee_5185

struct WA3_Chatterjee_5185Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
